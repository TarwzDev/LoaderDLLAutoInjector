﻿Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Threading
Public Class Form3

    Dim button As Integer
    Dim filename As String = Guid.NewGuid().ToString + ".exe"

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Value += 1
        Dim appPath As String = My.Application.Info.DirectoryPath
        '  Dim fileReader As System.IO.StreamReader
        ' fileReader = My.Computer.FileSystem.OpenTextFileReader("C:\Windows\Temp\M\m.hook.path")
        '  Dim stringReader As String
        '   stringReader = fileReader.ReadLine()

        If (ProgressBar1.Value = ProgressBar1.Maximum) Then
            Timer1.Enabled = False
        End If

        If (ProgressBar1.Value >= 0) Then

            Try
                '     System.IO.File.Delete(stringReader)
            Catch ex As Exception
            End Try

            '   File.Delete(StringReader)
            Label1.Text = "Status: Remova a versão antiga do local"
        End If

        If (ProgressBar1.Value = 20) Then

            My.Computer.Network.DownloadFile("http://localhost/Loader.exe", TextBox1.Text)

            Label1.Text = "Status: Baixando a nova versão"
        End If

        If (ProgressBar1.Value > 21) Then
            Label1.Text = "Status: Baixando a nova versão"
        End If

        If (ProgressBar1.Value >= 50) Then
            Label1.Text = "Status: Preparando para executar a nova versão"

            If My.Computer.FileSystem.FileExists(TextBox1.Text) Then

            Else
                Label1.Text = "ERRO: Nova versão não encontrada!"
                ProgressBar1.Value = 0
            End If
        End If

        If (ProgressBar1.Value = 100) Then
            Timer1.Stop()
            Label1.Text = "Status: Atualização completa."
            button = 0
            Process.Start(TextBox1.Text)
            Thread.Sleep(500)
            Application.Exit()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim appPath As String = My.Application.Info.DirectoryPath
        Timer1.Enabled = True
        If (button = 1) Then
            Button1.Enabled = False
        End If
        If (button = 0) Then
            Button1.Text = "Start"
        End If
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        Label1.Text = "Status: Aguardando entrada do usuário"
        button = 1
        Dim appPath As String = My.Application.Info.DirectoryPath
        TextBox1.Text = appPath + "\" + filename
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub
End Class